export { ApiService, } from "@wisegar-org/wgo-opengar-core-ui";
//# sourceMappingURL=ApiService.js.map