export const LANGUAGE_PATH_GET_ALL_LANGUAGE = "getAllLanguage";
export const LANGUAGE_PATH_GET_LANGUAGE = "getLanguage";
export const LANGUAGE_PATH_POST_LANGUAGE = "postLanguage";
export const LANGUAGE_PATH_PUT_LANGUAGE = "putLanguage";
