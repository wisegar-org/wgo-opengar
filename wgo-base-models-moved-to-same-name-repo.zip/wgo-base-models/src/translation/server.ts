export const TRANSLATION_PATH_GET_ALL_TRANSLATION = "getAllTranslations";
export const TRANSLATION_PATH_GET_ALL_BY_KEYS = "getAllTranslationsByKeys";
export const TRANSLATION_PATH_SET_TRANSLATION = "setTranslation";
export const TRANSLATION_PATH_DELETE_TRANSLATION = "deleteTranslation";
export const TRANSLATION_PATH_IMPORT_TRANSLATION = "importTranslations";
export const TRANSLATION_PATH_EXPORT_TRANSLATION = "exportTranslations";
