export interface IIdInput {
  id: number;
}
