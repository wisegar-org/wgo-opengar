export interface ISeoModel {
  title: string;
  webSite?: string;
  description?: string;
  keywords?: string;
  equiv?: string;
}
