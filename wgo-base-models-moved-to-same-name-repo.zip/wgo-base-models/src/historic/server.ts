export const HISTORIC_PATH_GET_PAGE = "getHistoricPage";
export const HISTORIC_PATH_GET_FILTERS = "getHistoricFilters";
