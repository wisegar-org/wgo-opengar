export const SETTINGS_PATH_GET_ALL_SETTINGS = "getAllSettings";
export const SETTINGS_PATH_GET_SETTINGS = "getSettings";
export const SETTINGS_PATH_SET_SETTING = "setSetting";
export const SETTINGS_PATH_DELETE_SETTINGS = "deleteSettings";
