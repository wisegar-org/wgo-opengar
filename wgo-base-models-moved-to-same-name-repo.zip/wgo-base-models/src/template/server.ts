export const TEMPLATE_PATH_GET_BY_TYPE = "getTemplateByType";
export const TEMPLATE_PATH_POST = "postTemplate";
