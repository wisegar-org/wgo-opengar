export const APP_TEMPLATE = "APP_TEMPLATE";

export const templateServerTranslations = [];
