export const MEDIA_FILES_PATH = "media";

export const StorageKeys = "WGO_STORAGE_CONTENT";
