export const CONTACT_ME_PATH_GET_CONTACT_ME = "getContactData";
export const CONTACT_ME_PATH_SET_CONTACT_ME = "setContactData";
