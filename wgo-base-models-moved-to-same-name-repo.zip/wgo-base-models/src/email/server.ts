export const EMAIL_PATH_SEND_EMAIL = "sendEmail";
export const EMAIL_PATH_SEND_EMAIL_TO_APP = "sendEmailToApp";
export const EMAIL_PATH_SEND_EMAIL_FROM_TO_APP = "sendEmailFromToApp";
export const EMAIL_PATH_SEND_EMAIL_FROM_TO_ADDRESS_AND_APP =
  "sendEmailFromToAddressAndApp";
