export type IBuildCallback = (cmd?: string) => any;
