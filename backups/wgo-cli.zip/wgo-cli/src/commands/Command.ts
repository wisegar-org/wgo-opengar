import { ICmdOptions } from "../options/ICmdOptions";

export class Command {
  public static CMD: string;
  public static Description: string;
  public static HelpOption: ICmdOptions;
}
