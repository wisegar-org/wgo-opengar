<template>
  <q-page class="flex flex-center">
    <q-btn icon="add">Hola</q-btn>
  </q-page>
</template>

<style></style>

<script>
export default {
  name: "HelloWorld",
};
</script>
