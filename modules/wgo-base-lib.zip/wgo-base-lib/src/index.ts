import HelloWorld from "@/components/HelloWorld.vue";

const Components = {
  HelloWorld,
};
export default Components;
