import { addCasinaIndexContentDatabase1659037006696 } from "./1659037006696-addCasinaIndexContentDatabase";

export const getCasinaMigrations = () => {
  return [addCasinaIndexContentDatabase1659037006696];
};
