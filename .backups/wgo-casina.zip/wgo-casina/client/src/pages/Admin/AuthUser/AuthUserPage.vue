<template>
  <UsersList :tranStore="translationStore" :authStore="authStore" @success="success" />
</template>

<script lang="ts">
import { useTranslationStore } from '../../../stores/translationStore';
import { defineComponent } from 'vue';
import { useNotifyStore } from '../../../stores/notifyStore';
import { TranslationStore } from '@wisegar-org/wgo-base-client/build/translation/store/TranslationStore';
import UsersList from '@wisegar-org/wgo-base-client/build/authentication/components/UsersList/UsersList.vue';
import { useAuthStore } from '../../../stores/authStore';

export default defineComponent({
  name: 'AuthUserPage',
  components: {
    UsersList,
  },
  setup() {
    const translationStore = useTranslationStore();
    const notifyStore = useNotifyStore();
    const authStore = useAuthStore();
    return {
      translationStore: translationStore.translationStore as TranslationStore,
      authStore: authStore.authStore,
      notifyStore,
    };
  },
  methods: {
    success(msg: string) {
      this.notifyStore.setNotify({
        position: 'top',
        type: 'positive',
        message: msg,
      });
    },
  },
});
</script>
