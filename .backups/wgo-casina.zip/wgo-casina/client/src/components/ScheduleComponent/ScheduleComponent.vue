<template>
  <div class="q-pa-md">
    <div class="q-pt-xl q-pb-md text-h4" v-html="getLabel(translations.CASINA_INDEX_SCHEDULE_TITLE_TEXT)"></div>
    <div class="q-pb-xl q-pt-md text-body1" v-html="getLabel(translations.CASINA_INDEX_SCHEDULE_CONTENT_TEXT)"></div>
  </div>
</template>

<script lang="ts" src="./ScheduleComponent.ts" />
