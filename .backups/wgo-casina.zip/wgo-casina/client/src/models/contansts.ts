export const CasinaDoctorType = 'casina_doctor';
export const CasinaServiceType = 'casina_service';
