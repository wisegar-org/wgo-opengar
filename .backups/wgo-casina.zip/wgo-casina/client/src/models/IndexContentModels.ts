import { IMediaModel } from '@wisegar-org/wgo-base-models/build/core';

export interface IndexContentModel {
  image?: IMediaModel;
}
