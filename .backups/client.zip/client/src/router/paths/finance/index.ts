export const FinanceBasePath = "/fin";
