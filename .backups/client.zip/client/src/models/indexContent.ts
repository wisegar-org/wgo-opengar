export interface StorageIndexContentModules {
  name: string;
  description: string;
  nameKey: string;
  descriptionKey: string;
  path: string;
}

export const MODULES_STORAGE_TYPE = "WISEGAR_MODULES";
