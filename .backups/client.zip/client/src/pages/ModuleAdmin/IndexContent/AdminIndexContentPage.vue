<template>
  <div>
    Blank page
    <p class="text-red">TODO: put content</p>
  </div>
</template>
