import { MediaResponseGql } from 'src/graphql';

export interface IndexContentModel {
  image?: MediaResponseGql;
}
