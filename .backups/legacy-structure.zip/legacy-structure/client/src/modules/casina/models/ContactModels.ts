
export interface ContactData {
    contactName: string,
    address: string,
    email: string,
    phoneNumber: string,
    mapPath: string
}
  