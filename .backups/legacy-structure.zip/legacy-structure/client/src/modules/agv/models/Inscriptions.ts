export interface IInscriptionResponseFilter {
  eventClass: string;
  eventTitle: string;
  nome: string;
  phone: string;
  email: string;
  class: string;
}
