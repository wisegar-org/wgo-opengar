import { AGVLayout } from '../settings/RouterSettings';

export default AGVLayout;
