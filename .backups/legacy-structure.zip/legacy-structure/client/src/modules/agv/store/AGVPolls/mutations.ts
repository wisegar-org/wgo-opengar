import { MutationTree } from 'vuex';
import { AGVPollsStateInterface } from './state';

export const agvPollsMutationsKeys = {};

const mutation: MutationTree<AGVPollsStateInterface> = {};

export default mutation;
