import { ActionTree } from 'vuex';
import { AGVPollsStateInterface } from './state';

export const agvPollsActionsKeys = {};

const actions: ActionTree<AGVPollsStateInterface, any> = {};

export default actions;
