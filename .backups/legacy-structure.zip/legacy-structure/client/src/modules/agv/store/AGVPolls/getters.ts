import { GetterTree } from 'vuex';
import { AGVPollsStateInterface } from './state';

export const agvPollsGettersKeys = {};

const getters: GetterTree<AGVPollsStateInterface, any> = {};

export default getters;
