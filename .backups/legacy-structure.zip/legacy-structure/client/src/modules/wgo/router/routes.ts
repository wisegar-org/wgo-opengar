import { WGOLayout } from '../settings/RouterSettings';

export default WGOLayout;
