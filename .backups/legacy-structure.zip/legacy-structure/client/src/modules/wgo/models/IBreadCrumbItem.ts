export interface IBreadCrumbItem {
  to: string;
  icon: string;
  label: string;
  roleFilter?: string;
  hideMenu?: boolean;
  hideBC?: boolean;
}
