export interface IContact {
    module: string,
    contactName: string,
    address: string,
    email: string,
    phoneNumber: string,
    mapPath: string
}