import settings from './ApiSettings';
export * from './ApiSettings';

export const axios = settings.axios;
export const ApiSettings = settings.settings;
