import Vue from 'vue'
import VueApollo from 'vue-apollo'

Vue.use(VueApollo)