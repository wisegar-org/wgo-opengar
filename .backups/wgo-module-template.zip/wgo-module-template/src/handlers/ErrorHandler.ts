export const errorHandler = (err: Error) => {
  console.log(err);
  return err;
};
