export const getDefaultHeader = () => {
  return {
    headerClass: {
      home: "",
      comitato: "",
      contatto: "",
      corsi: "",
      eventi: "",
      link_utili: "",
    },
    showLayout: true,
  };
};
