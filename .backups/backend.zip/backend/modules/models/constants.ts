export const USER_ROLE = "USER";

export const READ_EMAILS_INTERVAL = 1 * 60 * 1000; // 1 minutes
