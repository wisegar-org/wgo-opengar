# Servicios implementados

- Pop3Service: Servicio de lectura y recepcion de correos electronicos. Para mas detalles ver 2.1 (link)
