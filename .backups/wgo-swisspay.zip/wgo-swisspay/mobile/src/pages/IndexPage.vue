<template>
  <q-page class="row items-center justify-evenly">
    <div class="col-12"></div>
  </q-page>
</template>

<script lang="ts">
import { defineComponent } from "vue";

export default defineComponent({
  name: "IndexPage",
  components: {},
  setup() {
    return {};
  },
});
</script>
