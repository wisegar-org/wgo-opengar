//Translations base components
import { getCoreTranslationsKeys } from '@wisegar-org/wgo-base-models/build/core';
import { getTranslationTranslationsKeys } from '@wisegar-org/wgo-base-models/build/translation';
import { getLanguageTranslationsKeys } from '@wisegar-org/wgo-base-models/build/language';
import { getAuthTranslationsKeys } from '@wisegar-org/wgo-base-models/build/authentication';
import { getSettingsTranslationsKeys } from '@wisegar-org/wgo-base-models/build/settings';

//Project translation components
import { getEmailMediaTranslationsKeys } from '../components/EmailMedia/translations';
import { getEmployeesTranslationsKeys } from '../components/Employees/translations';

const tanslations: string[] = getCoreTranslationsKeys()
  .concat(getTranslationTranslationsKeys())
  .concat(getLanguageTranslationsKeys())
  .concat(getAuthTranslationsKeys())
  .concat(getEmailMediaTranslationsKeys())
  .concat(getSettingsTranslationsKeys())
  .concat(getEmployeesTranslationsKeys());
export const Translations = tanslations;
