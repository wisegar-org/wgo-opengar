<template>
  <q-page class="row items-center justify-between">
    <div class="col-12">
      <!-- <hello-world /> -->
    </div>
  </q-page>
</template>

<script lang="ts">
// import ExampleComponent from "../components/ExampleComponent.vue";
import { defineComponent, ref } from 'vue';

export default defineComponent({
  name: 'IndexPage',
  components: {},
  setup() {},
});
</script>
