<template>
  <LanguageList :langStore="langStore" :tranStore="tranStore" @success="onSuccess" />
</template>

<script lang="ts">
import { defineComponent } from 'vue';
import LanguageList from '@wisegar-org/wgo-base-client/build/language/components/LanguageList/LanguageList.vue';
import { LanguageStore } from '@wisegar-org/wgo-base-client/build/language/store/LanguageStore';
import { TranslationStore } from '@wisegar-org/wgo-base-client/build/translation/store/TranslationStore';
import { useLanguageStore } from '../../../stores/languageStore';
import { useNotifyStore } from '../../../stores/notifyStore';
import { useTranslationStore } from '../../../stores/translationStore';

export default defineComponent({
  name: 'LanguagePage',
  components: {
    LanguageList,
  },
  setup() {
    const languageStore = useLanguageStore();
    const translationStore = useTranslationStore();
    const notifyStore = useNotifyStore();
    return {
      langStore: languageStore.languageStore as LanguageStore,
      tranStore: translationStore.translationStore as TranslationStore,
      notifyStore,
    };
  },
  methods: {
    onSuccess(msg: string) {
      this.notifyStore.setNotify({
        position: 'top',
        type: 'positive',
        message: msg || '',
      });
    },
  },
});
</script>
