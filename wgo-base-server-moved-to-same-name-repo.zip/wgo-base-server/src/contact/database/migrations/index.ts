import { addContactMeEntity1658932057343 } from "./1658932057343-addContactMeEntity";
import { addContactMeHistoric1668549723950 } from "./1668549723950-addContactMeHistoric";

export const getContactMigrations = () => {
  return [addContactMeEntity1658932057343, addContactMeHistoric1668549723950];
};
