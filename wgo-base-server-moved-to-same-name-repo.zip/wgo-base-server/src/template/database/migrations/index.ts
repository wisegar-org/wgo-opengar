import { createTemplateTable1668532715433 } from "./1668532715433-createTemplateTable";
import { addTemplateHistoric1668553582516 } from "./1668553582516-addTemplateHistoric";

export const getTemplateMigrations = () => {
  return [createTemplateTable1668532715433, addTemplateHistoric1668553582516];
};
