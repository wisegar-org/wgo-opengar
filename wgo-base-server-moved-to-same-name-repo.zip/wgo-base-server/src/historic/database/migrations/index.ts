import { createHistoricTable1668532176196 } from "./1668532176196-createHistoricTable";

export const getHistoricMigrations = () => {
  return [createHistoricTable1668532176196];
};
