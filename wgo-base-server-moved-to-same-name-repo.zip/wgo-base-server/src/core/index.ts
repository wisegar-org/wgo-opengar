export { WGBaseEntity } from "./database/entities/WGBaseEntity";
export * from "./resolvers/CoreInputs";
export * from "./resolvers/CoreResponses";
export * from "./resolvers/CoreResolver";
export * from "./services/UtilService";
export * from "./services/CoreService";
